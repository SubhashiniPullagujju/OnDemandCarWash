package com.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bean.AdminBean;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.service.ServiceDao;
import com.validate.Validate;

@Controller
public class UserController {

	@Autowired
	private ServiceDao service;

	@Autowired
	private Validate validate;

	@ModelAttribute("index")
	public UserBean userBean() {
		return new UserBean();
	}

	@ModelAttribute("aindex")
	public AdminBean adminBean() {
		return new AdminBean();
	}

	@ModelAttribute("vindex")
	public VendorBean vendorBean() {
		return new VendorBean();
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String showIndexpage(@ModelAttribute("index") UserBean index) {

		return "Homepage";

	}

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public String User(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Index";

	}

	@RequestMapping(value = "/submitlogin", method = RequestMethod.POST)
	public String LoginVlidation(@Valid @ModelAttribute("index") UserBean index, BindingResult result) {
		validate.userpassworderror(index, result);
		if (service.userloginvalidate(index)) {
			return "Login";
		}
		else if (result.hasErrors()) {
			return "Index";
		}
		return "Registration";

	}

	@RequestMapping(value = "/submitsignup", method = RequestMethod.POST)
	public String RegistrationPageDisplay(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Registration";
	}

	@RequestMapping(value = "/submitregistration", method = RequestMethod.POST)
	public String RegistrationValidations(@Valid @ModelAttribute("index") UserBean index, BindingResult result) {

		validate.validate(index, result);
		if (result.hasErrors()) {
			return "Registration";
		} else if (service.userinsertvalues(index) > 0) {
			return "Index";
		}
		return "Registration";
	}

	@RequestMapping(value = "/admin", method = RequestMethod.POST)
	public String Admin(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminlogin", method = RequestMethod.POST)
	public String AdminLoginVlidation(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		validate.adminpassworderror(aindex, result);
		if (result.hasErrors()) {
			return "AdminIndex";
		}
		if (service.adminloginvalidate(aindex)) {
			return "AdminHomePage";
		}
		return "AdminIndex";

	}

	@RequestMapping(value = "/submitadminsignup", method = RequestMethod.POST)
	public String AdminRegistrationPageDisplay(@ModelAttribute("aindex") AdminBean aindex, BindingResult result) {
		return "AdminRegistration";
	}

	@RequestMapping(value = "/submitadminregistration", method = RequestMethod.POST)
	public String AdminRegistrationValidations(@Valid @ModelAttribute("aindex") AdminBean aindex,
			BindingResult result) {

		validate.validate1(aindex, result);
		if (result.hasErrors()) {
			return "AdminRegistration";
		} else if (service.admininsertvalues(aindex) > 0) {
			return "AdminIndex";
		}
		return "AdminRegistration";
	}

	@RequestMapping(value = "/vendor", method = RequestMethod.POST)
	public String Vendor(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorIndex";

	}

	@RequestMapping(value = "/submitvendorlogin", method = RequestMethod.POST)
	public String VendorLoginValidation(@ModelAttribute("vindex") VendorBean vindex, BindingResult result, Model m) {
		validate.vendorpassworderror(vindex, result);
		if(result.hasErrors())
		{
			return "VendorIndex";
		}
		if (service.vendorloginvalidate(vindex)) 
		{
			service.washingservicecheck(vindex);
			service.fetchvendordetails(vindex);
			m.addAttribute("vendorindex", vindex);
			return "VendorHomePage";
		}
		return "VendorIndex";

	}

	@RequestMapping(value = "/submitvendorsignup", method = RequestMethod.POST)
	public String VendorRegistrationPageDisplay(@ModelAttribute("vindex") VendorBean vindex, BindingResult result) {
		return "VendorRegistration";
	}

	@RequestMapping(value = "/submitvendorregistration", method = RequestMethod.POST)
	public String VendorRegistrationValidations(@Valid @ModelAttribute("vindex") VendorBean vindex,
			BindingResult result) {
		validate.vendor(vindex, result);
		if (result.hasErrors()) {
			return "VendorRegistration";
		} else if (service.vendorinsertvalues(vindex) > 0) {
			return "VendorIndex";
		}
		return "VendorRegistration";
	}
	@RequestMapping(value = "/ServiceCenterDetails", method = RequestMethod.POST)
	public String vendorWashingServiceDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.vendorservicecheck(vindex))
		{
			if(service.updateServiceDetails(vindex)>0)
			{
				return "VendorHomePage";
			}
		}
		else {
		if(service.insertServiceDetails(vindex)>0)
		{
			return "VendorHomePage";
		}
		}
		return "Login";
	}
	@RequestMapping(value = "/Updatepersonaldetails", method = RequestMethod.POST)
	public String vendorDetailsUpdate(@ModelAttribute("vindex") VendorBean vindex,BindingResult result,Model m) {
		if(service.updateServiceDetails(vindex)>0)
		{
			return "VendorHomePage";
		}
		return "Login";
	}
	
	@RequestMapping(value = "/forgetpassword", method = RequestMethod.POST)
	public String Forgotpassword(@ModelAttribute("index") UserBean index, BindingResult result) {
		return "Forgotpassword";

	}
}