package com.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class VendorBean {

	@NotBlank(message = "First Name is mandatory")
	private String firstName;
	private String lastName="null";
	@NotBlank(message="Age is mandatory")
	private String age;
	@NotBlank(message="Gender is mandatory")
	private String gender;
	@NotBlank(message = "Contact Number is mandatory")
	@Pattern(regexp="^[7-9]{1}[0-9]{9}",message="Contact number should be ten digits")
	private String contactNumber;
	@NotBlank(message = "Password is mandatory")
	private String password;
	@NotBlank(message = "VendorId is mandatory")
	private String vendorId;
	private String errorcheck;
	private String landlineNumber="empty";
	private String address="empty";
	private String emailId="empty";
	private String washingCenterName="empty";
	private String washingCenterType="empty";
	private String washingCenterAddress="empty";
	private String washingCenterContact="empty";
	private String washingCenterTime="empty";
	public String getLandlineNumber() {
		return landlineNumber;
	}

	public void setLandlineNumber(String landlineNumber) {
		this.landlineNumber = landlineNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getWashingCenterName() {
		return washingCenterName;
	}

	public void setWashingCenterName(String washingCenterName) {
		this.washingCenterName = washingCenterName;
	}

	public String getWashingCenterType() {
		return washingCenterType;
	}

	public void setWashingCenterType(String washingCenterType) {
		this.washingCenterType = washingCenterType;
	}

	public String getWashingCenterAddress() {
		return washingCenterAddress;
	}

	public void setWashingCenterAddress(String washingCenterAddress) {
		this.washingCenterAddress = washingCenterAddress;
	}

	public String getWashingCenterContact() {
		return washingCenterContact;
	}

	public void setWashingCenterContact(String washingCenterContact) {
		this.washingCenterContact = washingCenterContact;
	}

	public String getWashingCenterTime() {
		return washingCenterTime;
	}

	public void setWashingCenterTime(String washingCenterTime) {
		this.washingCenterTime = washingCenterTime;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getErrorcheck() {
		return errorcheck;
	}

	public void setErrorcheck(String errorcheck) {
		this.errorcheck = errorcheck;
	}
}
