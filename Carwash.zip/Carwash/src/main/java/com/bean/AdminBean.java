package com.bean;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

public class AdminBean{
	
	@NotBlank(message = "First Name is mandatory")
	private String First_Name;
	private String Last_name;
	@NotBlank(message = "Contact Number is mandatory")
	@Pattern(regexp="^[7-9]{1}[0-9]{9}",message="Contact number should be ten digits") 
	private String Contact_Number;
	@NotBlank(message = "Email is mandatory")
	@javax.validation.constraints.Email
	private String Email;
	@NotBlank(message = "Password is mandatory")
	private String Password;
	private String errorcheck;
	public String getFirst_Name() {
		return First_Name;
	}

	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}

	public String getLast_name() {
		return Last_name;
	}

	public void setLast_name(String last_name) {
		Last_name = last_name;
	}

	public String getContact_Number() {
		return Contact_Number;
	}

	public void setContact_Number(String contact_Number) {
		Contact_Number = contact_Number;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getErrorcheck() {
		return errorcheck;
	}

	public void setErrorcheck(String errorcheck) {
		this.errorcheck = errorcheck;
	}
}
