package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.springframework.stereotype.Service;
import com.bean.AdminBean;
import com.bean.UserBean;
import com.bean.VendorBean;
import com.connection.Dao;

@Service
public class ServiceDao {

	public int userinsertvalues(UserBean bean) {
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into usertable values(?,?,?,?,?)");
			ps.setString(1, bean.getFirst_Name());
			ps.setString(2, bean.getLast_name());
			ps.setString(3, bean.getContact_Number());
			ps.setString(4, bean.getEmail());
			ps.setString(5, bean.getPassword());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean userloginvalidate(UserBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from usertable where email=? and password=?");
			ps.setString(1, bean.getEmail());
			ps.setString(2, bean.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean adminloginvalidate(AdminBean aindex) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where email=? and password=?");
			ps.setString(1, aindex.getEmail());
			ps.setString(2, aindex.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int admininsertvalues(AdminBean aindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into admin values(?,?,?,?,?)");
			ps.setString(1, aindex.getFirst_Name());

			ps.setString(2, aindex.getLast_name());
			ps.setString(3, aindex.getContact_Number());
			ps.setString(4, aindex.getEmail());
			ps.setString(5, aindex.getPassword());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean vendorloginvalidate(VendorBean vindex) {
		// TODO Auto-generated method stub

		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=? and password=?");
			ps.setString(1, vindex.getVendorId());
			ps.setString(2, vindex.getPassword());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public int vendorinsertvalues(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into vendor values(?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, vindex.getFirstName());
			ps.setString(2, vindex.getLastName());
			ps.setString(5, vindex.getContactNumber());
			ps.setString(6, vindex.getVendorId());
			ps.setString(7, vindex.getPassword());
			ps.setString(3, vindex.getAge());
			ps.setString(4, vindex.getGender());
			ps.setString(8, "empty");
			ps.setString(9, "empty");
			ps.setString(10, "empty");
			ps.setString(11, "pending");
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean userduplicatecheck(UserBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from usertable where email=?");
			ps.setString(1, bean.getEmail());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean adminduplicatecheck(AdminBean bean) {
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from admin where email=?");
			ps.setString(1, bean.getEmail());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;

	}

	public boolean vendorduplicatecheck(VendorBean vendorbean) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=?");
			ps.setString(1, vendorbean.getVendorId());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	public void washingservicecheck(VendorBean vindex) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from servicedetails where Vendor_Id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				vindex.setWashingCenterName(rs.getString("washingCenterName"));
				vindex.setWashingCenterType(rs.getString("washingCenterType"));
				vindex.setVendorId(rs.getString("Vendor_Id"));
				vindex.setWashingCenterTime(rs.getString("washingCenterTime"));
				vindex.setWashingCenterContact(rs.getString("washingCenterContact"));
				vindex.setWashingCenterAddress(rs.getString("washingCenterAddress"));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int insertServiceDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into servicedetails values(?,?,?,?,?,?)");
			ps.setString(1, vindex.getVendorId());
			ps.setString(2, vindex.getWashingCenterName());
			ps.setString(3, vindex.getWashingCenterType());
			ps.setString(4, vindex.getWashingCenterTime());
			ps.setString(5, vindex.getWashingCenterContact());
			ps.setString(6, vindex.getWashingCenterAddress());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public void fetchvendordetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from vendor where vendor_id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				vindex.setFirstName((rs.getString("first_name")));
				vindex.setLastName(("last_name"));
				vindex.setAge((rs.getString("age")));
				vindex.setGender((rs.getString("gender")));
				vindex.setContactNumber((rs.getString("contact_number")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int updateVendorDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con
					.prepareStatement("update vendor set Alternate_Number=?,Address=?,Email_Id=? where vendor_id=?");
			ps.setString(1, vindex.getLandlineNumber());
			ps.setString(2, vindex.getAddress());
			ps.setString(3, vindex.getEmailId());
			ps.setString(4, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}

	public boolean vendorservicecheck(VendorBean vindex) {
		// TODO Auto-generated method stub
		boolean status = false;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from servicedetails where Vendor_Id=?");
			ps.setString(1, vindex.getVendorId());
			ResultSet rs = ps.executeQuery();
			status = rs.next();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return status;
	}

	public int updateServiceDetails(VendorBean vindex) {
		// TODO Auto-generated method stub
		int i = 0;
		try {
			Connection con = Dao.getConnection();
			PreparedStatement ps = con.prepareStatement("update servicedetails set washingCenterName=?,washingCenterType=?,washingCenterTime=?,washingCenterContact=?,washingCenterAddress=? where Vendor_Id=?");
			ps.setString(1, vindex.getWashingCenterName());
			ps.setString(2, vindex.getWashingCenterType());
			ps.setString(3, vindex.getWashingCenterTime());
			ps.setString(4, vindex.getWashingCenterContact());
			ps.setString(5, vindex.getWashingCenterAddress());
			ps.setString(6, vindex.getVendorId());
			i = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return i;
	}
}
